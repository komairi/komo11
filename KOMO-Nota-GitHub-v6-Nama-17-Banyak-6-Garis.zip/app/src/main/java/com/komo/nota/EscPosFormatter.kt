package com.komo.nota

import java.text.NumberFormat
import java.util.Locale

object EscPosFormatter {
    private const val WIDTH = 42
    // Nama barang diperpanjang 4 karakter dari versi sebelumnya.
    private const val NAME_WIDTH = 17
    private fun money(v: Long) = NumberFormat.getNumberInstance(Locale("id", "ID")).format(v)
    private fun fit(text: String, width: Int): String = text.padEnd(width).take(width)
    private fun wrap(text: String, width: Int): List<String> = text.chunked(width).ifEmpty { listOf("") }
    private fun right(text: String, width: Int): String = if (text.length <= width) text.padStart(width) else text.takeLast(width)

    fun preview(items: List<NotaItem>): String = buildString {
        append(center("KOMO")); append('\n')
        append(center("Dsn Wonosari Wetan")); append('\n')
        append(center("Kec. Glagah")); append('\n')
        append("-".repeat(WIDTH)).append('\n')
        append(fit("Nama Barang", NAME_WIDTH)).append(right("Harga", 7)).append(" ").append(right("Banyak", 6)).append(right("Total", 7)).append('\n')
        append("-".repeat(WIDTH)).append('\n')
        items.forEach { item ->
            val lines = wrap(item.name, NAME_WIDTH)
            append(fit(lines.first(), NAME_WIDTH))
            append(right(money(item.price), 7)).append(' ')
            append(right(item.qty.toString(), 6))
            append(right(money(item.price * item.qty), 7)).append('\n')
            lines.drop(1).forEach { line -> append(fit(line, NAME_WIDTH)).append('\n') }
        }
        append("-".repeat(WIDTH)).append('\n')
        append(right("TOTAL", WIDTH - 7)).append(right(money(items.sumOf { it.price * it.qty }), 7)).append('\n')
    }

    fun bytes(items: List<NotaItem>): ByteArray {
        val out = mutableListOf<Byte>()
        fun s(v: String) { out += v.toByteArray(Charsets.UTF_8).toList() }
        fun esc(vararg v: Int) { out += byteArrayOf(0x1B, *v.map { it.toByte() }.toByteArray()).toList() }
        esc(0x40); esc(0x61, 0x01); esc(0x21, 0x01); s("KOMO\n"); esc(0x21, 0x01)
        s("Dsn Wonosari Wetan\nKec. Glagah\n")
        s("-".repeat(WIDTH) + "\n")
        esc(0x61, 0x00)
        s(fit("Nama Barang", NAME_WIDTH) + right("Harga", 7) + " " + right("Banyak", 6) + right("Total", 7) + "\n")
        s("-".repeat(WIDTH) + "\n")
        items.forEach { item ->
            val lines = wrap(item.name, NAME_WIDTH)
            s(fit(lines.first(), NAME_WIDTH) + right(money(item.price), 7) + " " + right(item.qty.toString(), 6) + right(money(item.price * item.qty), 7) + "\n")
            lines.drop(1).forEach { line -> s(fit(line, NAME_WIDTH) + "\n") }
        }
        s("-".repeat(WIDTH) + "\n")
        s(right("TOTAL", WIDTH - 7) + right(money(items.sumOf { it.price * it.qty }), 7) + "\n")
        s("\n\n")
        esc(0x64, 0x03)
        return out.toByteArray()
    }

    private fun center(v: String): String = " ".repeat(((WIDTH - v.length).coerceAtLeast(0)) / 2) + v
}
