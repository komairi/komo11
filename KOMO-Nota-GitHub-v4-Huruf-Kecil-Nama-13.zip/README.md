# KOMO Nota Android

Aplikasi nota Android untuk toko **KOMO** dengan printer POS Bluetooth 58 mm.

## Format nota
- Toko: KOMO
- Alamat: Dsn Wonosari Wetan, Kec. Glagah
- Kolom: Nama Barang, Harga, Byk, Total
- Nama barang dibuat lebih lebar
- Byk maksimal 2 karakter
- Pemisah ribuan menggunakan titik: `5.000`, `125.000`
- Tidak mencetak tulisan tambahan seperti "Terima kasih"
- Layout dirancang hemat baris untuk kertas 58 mm

## Build di GitHub Actions
Workflow ada di `.github/workflows/build-apk.yml`.

Workflow menggunakan Gradle 8.7 secara langsung, sehingga **Gradle Wrapper tidak diperlukan**. APK debug akan tersedia pada bagian **Artifacts** setelah build berhasil.

> Penting: upload isi folder project ini ke **root repository GitHub**. Jangan membungkusnya lagi di folder `project/` atau `KOMO-Nota/` jika workflow digunakan apa adanya.


### Perubahan v4
- Huruf cetak dibuat lebih kecil menggunakan Font B ESC/POS.
- Lebar nama barang dikurangi dari 16 menjadi 13 karakter.
- Tampilan preview nota diperkecil menjadi 12sp.
