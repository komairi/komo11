package com.komo.nota

import java.text.NumberFormat
import java.util.Locale

object EscPosFormatter {
    private const val WIDTH = 32
    // Nama barang dipersingkat 3 karakter agar nota lebih lega di printer 58 mm.
    private const val NAME_WIDTH = 13
    private fun money(v: Long) = NumberFormat.getNumberInstance(Locale("id", "ID")).format(v)
    private fun fit(text: String, width: Int): String = if (text.length <= width) text.padEnd(width) else text.take(width - 1) + "…"
    private fun right(text: String, width: Int): String = if (text.length <= width) text.padStart(width) else text.takeLast(width)

    fun preview(items: List<NotaItem>): String = buildString {
        append(center("KOMO")); append('\n')
        append(center("Dsn Wonosari Wetan")); append('\n')
        append(center("Kec. Glagah")); append('\n')
        append("--------------------------------\n")
        append(fit("Nama Barang", NAME_WIDTH)).append(right("Harga", 7)).append(" ").append(right("Byk", 2)).append(right("Total", 7)).append('\n')
        append("--------------------------------\n")
        items.forEach { item ->
            append(fit(item.name, NAME_WIDTH))
            append(right(money(item.price), 7)).append(' ')
            append(right(item.qty.toString(), 2))
            append(right(money(item.price * item.qty), 7)).append('\n')
        }
        append("--------------------------------\n")
        append(right("TOTAL", 25)).append(right(money(items.sumOf { it.price * it.qty }), 7)).append('\n')
    }

    fun bytes(items: List<NotaItem>): ByteArray {
        val out = mutableListOf<Byte>()
        fun s(v: String) { out += v.toByteArray(Charsets.UTF_8).toList() }
        fun esc(vararg v: Int) { out += byteArrayOf(0x1B, *v.map { it.toByte() }.toByteArray()).toList() }
        esc(0x40); esc(0x61, 0x01); esc(0x21, 0x01); s("KOMO\n"); esc(0x21, 0x01)
        s("Dsn Wonosari Wetan\nKec. Glagah\n")
        s("--------------------------------\n")
        esc(0x61, 0x00)
        s(fit("Nama Barang", NAME_WIDTH) + right("Harga", 7) + " " + right("Byk", 2) + right("Total", 7) + "\n")
        s("--------------------------------\n")
        items.forEach { item -> s(fit(item.name, NAME_WIDTH) + right(money(item.price), 7) + " " + right(item.qty.toString(), 2) + right(money(item.price * item.qty), 7) + "\n") }
        s("--------------------------------\n")
        s(right("TOTAL", 25) + right(money(items.sumOf { it.price * it.qty }), 7) + "\n")
        s("\n\n")
        esc(0x64, 0x03)
        return out.toByteArray()
    }

    private fun center(v: String): String = " ".repeat(((WIDTH - v.length).coerceAtLeast(0)) / 2) + v
}
