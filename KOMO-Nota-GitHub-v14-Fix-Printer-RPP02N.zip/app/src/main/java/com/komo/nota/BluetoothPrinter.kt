package com.komo.nota

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.util.UUID

object BluetoothPrinter {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun print(device: BluetoothDevice, data: ByteArray) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        adapter?.cancelDiscovery()

        var socket: BluetoothSocket? = null
        var lastError: Exception? = null

        // RPP02N umumnya memakai Bluetooth Serial Port Profile (SPP).
        // Beberapa unit tidak menerima koneksi dari metode secure standar,
        // sehingga dicoba beberapa metode koneksi yang kompatibel.
        val attempts = listOf<() -> BluetoothSocket>(
            { device.createRfcommSocketToServiceRecord(SPP_UUID) },
            { device.createInsecureRfcommSocketToServiceRecord(SPP_UUID) },
            {
                val method = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                method.invoke(device, 1) as BluetoothSocket
            }
        )

        for (create in attempts) {
            try {
                socket?.close()
                socket = create()
                socket.connect()
                if (socket.isConnected) break
            } catch (e: Exception) {
                lastError = e
                try { socket?.close() } catch (_: Exception) {}
                socket = null
            }
        }

        val connectedSocket = socket ?: throw lastError ?: Exception("Tidak dapat terhubung ke printer")
        try {
            val output = connectedSocket.outputStream
            output.write(data)
            output.flush()
            // Beri waktu printer menerima seluruh buffer sebelum socket ditutup.
            Thread.sleep(350)
        } finally {
            try { connectedSocket.close() } catch (_: Exception) {}
        }
    }
}
