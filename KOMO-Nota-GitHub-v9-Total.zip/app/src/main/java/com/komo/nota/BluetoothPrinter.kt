package com.komo.nota

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import java.util.UUID

object BluetoothPrinter {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun print(device: BluetoothDevice, data: ByteArray) {
        val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
        socket.connect()
        try {
            socket.outputStream.use { it.write(data); it.flush() }
        } finally { socket.close() }
    }
}
