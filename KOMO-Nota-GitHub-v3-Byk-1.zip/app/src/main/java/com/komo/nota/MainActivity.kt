package com.komo.nota

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val items = mutableListOf<NotaItem>()
    private var selectedPrinter: BluetoothDevice? = null
    private lateinit var preview: TextView
    private lateinit var totalText: TextView
    private lateinit var itemName: EditText
    private lateinit var itemPrice: EditText
    private lateinit var itemQty: EditText

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updatePrinterButton() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        totalText = findViewById(R.id.totalText)
        itemName = findViewById(R.id.itemName)
        itemPrice = findViewById(R.id.itemPrice)
        itemQty = findViewById(R.id.itemQty)

        findViewById<Button>(R.id.addButton).setOnClickListener { addItem() }
        findViewById<Button>(R.id.printerButton).setOnClickListener { choosePrinter() }
        findViewById<Button>(R.id.printButton).setOnClickListener { printNota() }
        findViewById<Button>(R.id.newButton).setOnClickListener { clearNota() }
        render()
    }

    private fun addItem() {
        val name = itemName.text.toString().trim()
        val price = itemPrice.text.toString().replace(".", "").replace(",", "").toLongOrNull()
        val qty = itemQty.text.toString().toIntOrNull()
        if (name.isEmpty() || price == null || price < 0 || qty == null || qty < 1 || qty > 99) {
            Toast.makeText(this, "Isi nama, harga, dan Byk 1-99", Toast.LENGTH_SHORT).show(); return
        }
        items.add(NotaItem(name, price, qty))
        itemName.text.clear(); itemPrice.text.clear(); itemQty.setText("1"); itemName.requestFocus()
        render()
    }

    private fun render() {
        preview.text = EscPosFormatter.preview(items)
        totalText.text = "TOTAL: ${money(items.sumOf { it.price * it.qty })}"
    }

    @SuppressLint("MissingPermission")
    private fun choosePrinter() {
        if (!hasBluetoothPermission()) { requestBluetoothPermission(); return }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("Perangkat tidak mendukung Bluetooth"); return }
        if (!adapter.isEnabled) { toast("Aktifkan Bluetooth terlebih dahulu"); return }
        val paired = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
        if (paired.isEmpty()) { toast("Belum ada printer yang dipasangkan di pengaturan Bluetooth"); return }
        val names = paired.map { "${it.name ?: "Printer"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pilih Printer POS 58 mm")
            .setItems(names) { _, which -> selectedPrinter = paired[which]; updatePrinterButton() }
            .setNegativeButton("Batal", null).show()
    }

    private fun updatePrinterButton() {
        findViewById<Button>(R.id.printerButton).text = selectedPrinter?.let { "Printer: ${it.name ?: it.address}" } ?: "Pilih Printer Bluetooth"
    }

    private fun printNota() {
        if (items.isEmpty()) { toast("Belum ada barang"); return }
        if (!hasBluetoothPermission()) { requestBluetoothPermission(); return }
        val device = selectedPrinter ?: run { choosePrinter(); return }
        Thread {
            try {
                BluetoothPrinter.print(device, EscPosFormatter.bytes(items))
                runOnUiThread { toast("Nota berhasil dicetak") }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal mencetak: ${e.message ?: "periksa printer"}") }
            }
        }.start()
    }

    private fun clearNota() {
        items.clear(); render(); itemName.text.clear(); itemPrice.text.clear(); itemQty.setText("1"); itemName.requestFocus()
    }

    private fun money(value: Long): String = NumberFormat.getNumberInstance(Locale("id", "ID")).format(value)
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun hasBluetoothPermission(): Boolean = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31) permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT))
    }
}

data class NotaItem(val name: String, val price: Long, val qty: Int)
