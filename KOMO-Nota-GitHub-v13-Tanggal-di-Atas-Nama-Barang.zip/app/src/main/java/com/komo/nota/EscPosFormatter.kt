package com.komo.nota

import java.text.NumberFormat
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date

object EscPosFormatter {
    private const val WIDTH = 42
    // Nama barang diperpanjang 4 karakter dari versi sebelumnya.
    private const val NAME_WIDTH = 17
    private const val SEP = "|"
    private const val PRICE_WIDTH = 7
    private const val QTY_WIDTH = 6
    private const val TOTAL_WIDTH = 7
    private fun money(v: Long) = NumberFormat.getNumberInstance(Locale("id", "ID")).format(v)
    private fun transactionDate(): String = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("id", "ID")).format(Date())
    private fun fit(text: String, width: Int): String = text.padEnd(width).take(width)
    private fun wrap(text: String, width: Int): List<String> = text.chunked(width).ifEmpty { listOf("") }
    private fun right(text: String, width: Int): String = if (text.length <= width) text.padStart(width) else text.takeLast(width)
    private fun centerFixed(text: String, width: Int): String {
        val t = text.take(width)
        val left = (width - t.length) / 2
        return " ".repeat(left) + t + " ".repeat(width - left - t.length)
    }

    fun preview(items: List<NotaItem>, bayar: Long = items.sumOf { it.price * it.qty }): String = buildString {
        append(center("KOMO")); append('\n')
        append(center("Dsn Wonosari Wetan Kec. Glagah")); append('\n')
        append(center("Hp: 085 232 636 024")); append('\n')
        append("-".repeat(WIDTH)).append('\n')
        append(center("Tgl: ${transactionDate()}")); append('\n')
        append(fit("Nama Barang", NAME_WIDTH)).append(SEP).append(right("Harga", PRICE_WIDTH)).append(SEP).append(centerFixed("Banyak", QTY_WIDTH)).append(SEP).append(right("Total", TOTAL_WIDTH)).append('\n')
        append("-".repeat(WIDTH)).append('\n')
        items.forEach { item ->
            val lines = wrap(item.name, NAME_WIDTH)
            append(fit(lines.first(), NAME_WIDTH)).append(SEP)
            append(right(money(item.price), PRICE_WIDTH)).append(SEP)
            append(centerFixed(item.qty.toString(), QTY_WIDTH)).append(SEP)
            append(right(money(item.price * item.qty), TOTAL_WIDTH)).append('\n')
            lines.drop(1).forEach { line -> append(fit(line, NAME_WIDTH)).append('\n') }
        }
        append("-".repeat(WIDTH)).append('\n')
        val total = items.sumOf { it.price * it.qty }
        append(totalLine(total)).append('\n')
        append(paymentLine("BAYAR", bayar)).append('\n')
        append(paymentLine(if (bayar >= total) "KEMBALIAN" else "KURANG", kotlin.math.abs(bayar - total))).append('\n')
    }

    fun bytes(items: List<NotaItem>, bayar: Long = items.sumOf { it.price * it.qty }): ByteArray {
        val out = mutableListOf<Byte>()
        fun s(v: String) { out += v.toByteArray(Charsets.UTF_8).toList() }
        fun esc(vararg v: Int) { out += byteArrayOf(0x1B, *v.map { it.toByte() }.toByteArray()).toList() }
        esc(0x40); esc(0x61, 0x01); esc(0x21, 0x01); s("KOMO\n"); esc(0x21, 0x01)
        s("Dsn Wonosari Wetan Kec. Glagah\nHp: 085 232 636 024\n")
        s("-".repeat(WIDTH) + "\n")
        esc(0x61, 0x01)
        s("Tgl: ${transactionDate()}\n")
        esc(0x61, 0x00)
        s(fit("Nama Barang", NAME_WIDTH) + SEP + right("Harga", PRICE_WIDTH) + SEP + centerFixed("Banyak", QTY_WIDTH) + SEP + right("Total", TOTAL_WIDTH) + "\n")
        s("-".repeat(WIDTH) + "\n")
        items.forEach { item ->
            val lines = wrap(item.name, NAME_WIDTH)
            s(fit(lines.first(), NAME_WIDTH) + SEP + right(money(item.price), PRICE_WIDTH) + SEP + centerFixed(item.qty.toString(), QTY_WIDTH) + SEP + right(money(item.price * item.qty), TOTAL_WIDTH) + "\n")
            lines.drop(1).forEach { line -> s(fit(line, NAME_WIDTH) + "\n") }
        }
        s("-".repeat(WIDTH) + "\n")
        val total = items.sumOf { it.price * it.qty }
        s(totalLine(total) + "\n")
        s(paymentLine("BAYAR", bayar) + "\n")
        s(paymentLine(if (bayar >= total) "KEMBALIAN" else "KURANG", kotlin.math.abs(bayar - total)) + "\n")
        s("\n\n")
        esc(0x64, 0x03)
        return out.toByteArray()
    }

    private fun paymentLine(label: String, value: Long): String = label + "  " + " ".repeat((WIDTH - label.length - 2 - TOTAL_WIDTH).coerceAtLeast(0)) + right(money(value), TOTAL_WIDTH)

    private fun totalLine(total: Long): String {
        val label = "TOTAL"
        val value = right(money(total), TOTAL_WIDTH)
        return label + "  " + " ".repeat((WIDTH - label.length - 2 - TOTAL_WIDTH).coerceAtLeast(0)) + value
    }

    private fun center(v: String): String = " ".repeat(((WIDTH - v.length).coerceAtLeast(0)) / 2) + v
}
